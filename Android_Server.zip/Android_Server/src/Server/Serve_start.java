package Server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
public class Serve_start {
    public static void main(String[] args) {
        try {
            ServerSocket ss=new ServerSocket(8080);
            System.out.println("�����������ɹ�");
            while(true){
                Socket socket=ss.accept();
                BufferedReader bd=new BufferedReader(new InputStreamReader(socket.getInputStream()));
                System.out.print("���յ���Ϣ     ");
                SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//�������ڸ�ʽ
                System.out.println(df.format(new Date()));// new Date()Ϊ��ȡ��ǰϵͳʱ��
                /**
                 * ����HTTP����
                 */
                String requestHeader;
                while((requestHeader=bd.readLine())!=null&&!requestHeader.isEmpty()){
                    System.out.println(requestHeader);
                    /**
                     * ���GET����
                     */
                    if(requestHeader.startsWith("GET")){
                        int begin = requestHeader.indexOf("/")+1;
                        int end = requestHeader.indexOf("HTTP/")-1;
                        String condition=requestHeader.substring(begin, end);
                        System.out.println("GET�����ǣ�"+condition);
                        System.out.println(begin+" "+end);
                        /**
                         * �ж��������
                         */
                        if(condition.equals("login")){
                        	//����һ��json����
//                            JSONObject jo = new JSONObject();
//                            try {
//    							jo.put("id", "16301009");
//    							jo.put("password", "yang");
//    	                        jo.put("age", "18");
//    						} catch (JSONException e) {
//    							// TODO Auto-generated catch block
//    							e.printStackTrace();
//    						}
                            //���ͻ�ִ��
                            OutputStream os = socket.getOutputStream();
            				
            				os.write("HTTP/1.1 404 The page not found\r\n".getBytes());
            				os.write("Content-Type:text/html;charset=utf-8\r\n".getBytes());
            				os.write("Content-Length:38\r\n".getBytes());
            				os.write("Server:gybs\r\n".getBytes());
            				os.write(("Date:"+new Date()+"\r\n").getBytes());
            				os.write("\r\n".getBytes());
//            				os.write("<h1>404!!!</h1>".getBytes());
//            				os.write(("<h3>���˳���</h3>").getBytes("utf-8"));
            				os.write("true".getBytes());
            				os.close();
            				socket.close();

                        }
                        else{
                        	OutputStream os = socket.getOutputStream();
            				
            				os.write("HTTP/1.1 404 The page not found\r\n".getBytes());
            				os.write("Content-Type:text/html;charset=utf-8\r\n".getBytes());
            				os.write("Content-Length:38\r\n".getBytes());
            				os.write("Server:gybs\r\n".getBytes());
            				os.write(("Date:"+new Date()+"\r\n").getBytes());
            				os.write("\r\n".getBytes());
            				os.write("true".getBytes());
            				os.close();
            				socket.close();
                        }
                    }
                    /**
                     * ���POST����
                     * 1.��ȡ�������ݳ���
                     */
                    if(requestHeader.startsWith("POST")){
                    	int begin = requestHeader.indexOf("/")+1;
                        int end = requestHeader.indexOf("HTTP/")-1;
                        String condition=requestHeader.substring(begin, end);
                        System.out.println("POST�����ǣ�"+condition);
                        System.out.println(begin+" "+end);
                        
                        //���ͻ�ִ��
                        OutputStream os = socket.getOutputStream();
        				
        				os.write("HTTP/1.1 404 The page not found\r\n".getBytes());
        				os.write("Content-Type:text/html;charset=utf-8\r\n".getBytes());
        				os.write("Content-Length:38\r\n".getBytes());
        				os.write("Server:gybs\r\n".getBytes());
        				os.write(("Date:"+new Date()+"\r\n").getBytes());
        				os.write("\r\n".getBytes());
        				os.write("true".getBytes());
        				os.close();
        				socket.close();
                        
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}